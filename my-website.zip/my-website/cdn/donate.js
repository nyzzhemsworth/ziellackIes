/*Fitur free
Fitur = donasi
Deskripsi = fitur donasi dengan menggunakan id qris minimal donasi 2000 
Type = plugins esm 
Kode = */
import crc from 'crc'
import {
    toDataURL
} from 'qrcode'

let handler = async (m, {
    conn,
    text
}) => {
    if (!text) return conn.reply(m.chat, 'Use example: .donasi 1000', m)
    if (isNaN(text)) return m.reply('harus berupa angka')
    if (text < 2000) return m.reply('nominal minimal 2000')
    let id = `isi id qrismu`;
    let result = await create(id, text);

    await conn.sendFile(m.chat, await toDataURL(result.slice(0, 2048), {
        scale: 8
    }), 'qrcode.png', `Donasi Rp${text}`, m)
}

handler.help = ['donasi']
handler.tags = ['tools']
handler.command = /^(donasi)$/i

export default handler

function create(qrisData, paymentAmount) {
    qrisData = qrisData.slice(0, -4);
    const step1 = qrisData.replace("010211", "010212");
    const step2 = step1.split("5802ID");

    const uang = "54" + ("0" + paymentAmount.length).slice(-2) + paymentAmount;
    const completeData = step2[0] + uang + step2[1] + convertCRC16(step2[0] + uang + step2[1]);

    return completeData;
}

function convertCRC16(str) {
    const crc16 = crc.crc16ccitt(Buffer.from(str, 'utf8')).toString(16).toUpperCase();
    return ("0000" + crc16).slice(-4);
}